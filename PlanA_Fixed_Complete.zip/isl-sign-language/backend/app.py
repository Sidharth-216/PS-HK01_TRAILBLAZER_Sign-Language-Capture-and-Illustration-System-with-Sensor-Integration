#!/usr/bin/env python3
"""
app.py — Plan A Flask Backend (Fixed & Complete)
Run from project root:
    cd isl-sign-language
    python backend/app.py
    Open: http://localhost:5000
"""

from flask import Flask, request, jsonify, render_template
import pickle, json, numpy as np, threading, time, os
from collections import deque, Counter

# ── TTS ───────────────────────────────────────────────────────
try:
    import pyttsx3
    tts_engine = pyttsx3.init()
    tts_engine.setProperty("rate", 150)
    tts_engine.setProperty("volume", 1.0)
    TTS_OK = True
    print("✓ TTS engine ready")
except Exception as e:
    TTS_OK = False
    print(f"⚠ TTS disabled: {e}")

app = Flask(__name__, template_folder="templates", static_folder="static")

# ── Load model (tries both relative paths) ────────────────────
model_data, meta = None, {}

for base in ["ml/models", "../ml/models"]:
    mp  = os.path.join(base, "gesture_model.pkl")
    mep = os.path.join(base, "gesture_meta.json")
    if os.path.exists(mp):
        with open(mp,  "rb") as f: model_data = pickle.load(f)
        with open(mep)       as f: meta = json.load(f)
        print(f"✓ Model loaded  : {meta['model_type']}")
        print(f"  Accuracy       : {meta['accuracy']}%")
        print(f"  Gestures       : {len(meta['gestures'])}")
        break

if model_data is None:
    print("⚠ No model found — run ml/train_model.py first")

# ── Shared state ──────────────────────────────────────────────
CONFIDENCE_MIN = 0.70
WINDOW         = 5

gesture_window = deque(maxlen=WINDOW)
history_log    = deque(maxlen=40)
sentence_words = []
tts_lock       = threading.Lock()

# latest_raw: always holds the most recent sensor readings from ESP32
# Used by GET /raw so collect_data.py can poll it
latest_raw = {"thumb": 0, "index": 0, "middle": 0, "ring": 0, "pinky": 0}

latest_gesture = {
    "gesture": "—", "confidence": 0, "raw": {},
    "timestamp": 0, "sentence": [], "icon": "🤚", "image": "default.png",
}

FEATURE_COLS = ["thumb", "index", "middle", "ring", "pinky"]

ICONS = {
    "Hello":"👋","ThankYou":"🙏","Yes":"✅","No":"❌",
    "Please":"🤲","Sorry":"😔","Help":"🆘","Water":"💧",
    "Food":"🍽️","Good":"👍","Bad":"👎","Stop":"✋",
    "Come":"🫴","Go":"🚶","Love":"❤️","Friend":"🤝",
    "A":"🅰️","B":"🅱️","C":"©️","D":"🔷","E":"📧",
    "F":"🖐️","G":"👉","H":"✋","I":"☝️","K":"✌️",
    "L":"👆","M":"🤙","N":"🤞","O":"⭕","R":"🤞",
    "S":"✊","T":"👍","U":"🤙","V":"✌️","W":"🤟",
    "X":"❌","Y":"🤙",
}

GESTURE_IMAGES = {
    "Hello":"hello.png","ThankYou":"thankyou.png",
    "Yes":"yes.png","No":"no.png","Help":"help.png",
    "Please":"please.png","Sorry":"sorry.png",
    "A":"isl_a.png","B":"isl_b.png","C":"isl_c.png",
}

# ── TTS ───────────────────────────────────────────────────────
def speak(text: str):
    """Speak text in a background thread so Flask doesn't block."""
    if not TTS_OK:
        return
    def _run():
        with tts_lock:
            tts_engine.say(text)
            tts_engine.runAndWait()
    threading.Thread(target=_run, daemon=True).start()

# ── Inference ─────────────────────────────────────────────────
def predict(sensor_dict: dict):
    """Run Random Forest on 5 sensor values. Returns (label, confidence)."""
    if model_data is None:
        return "No model", 0.0
    features = np.array([[sensor_dict.get(k, 0) for k in FEATURE_COLS]])
    scaled   = model_data["scaler"].transform(features)
    proba    = model_data["model"].predict_proba(scaled)[0]
    idx      = np.argmax(proba)
    label    = model_data["encoder"].inverse_transform([idx])[0]
    return label, float(proba[idx])

# ── Routes ─────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html",
                           gestures=meta.get("gestures", []),
                           meta=meta)

# ─────────────────────────────────────────────────────────────
# GET /raw
# Used by collect_data.py to poll sensor readings during data collection.
# The ESP32 also runs its own raw server on port 8080 — this is a
# Flask-side fallback for testing without the physical glove.
# ─────────────────────────────────────────────────────────────
@app.route("/raw", methods=["GET"])
def get_raw():
    return jsonify(latest_raw)

# ─────────────────────────────────────────────────────────────
# POST /gesture
# ESP32 sends {"thumb":2100,"index":1800,"middle":3000,"ring":2900,"pinky":1750}
# every ~800ms when PIR detects motion.
# ─────────────────────────────────────────────────────────────
@app.route("/gesture", methods=["POST"])
def receive_gesture():
    global latest_gesture, latest_raw

    data = request.get_json(force=True, silent=True)
    if not data:
        return jsonify({"error": "no JSON body"}), 400

    # Always update raw readings so sensor bars animate
    latest_raw = {k: int(data.get(k, 0)) for k in FEATURE_COLS}

    label, conf = predict(data)

    if conf >= CONFIDENCE_MIN:
        gesture_window.append(label)

        # Majority vote: same gesture must appear 3+ times in last 5 readings
        stable = (Counter(gesture_window).most_common(1)[0][0]
                  if len(gesture_window) >= 3 else label)

        # Add to sentence only if it's a new word
        if not sentence_words or sentence_words[-1] != stable:
            sentence_words.append(stable)
            if len(sentence_words) > 15:
                sentence_words.pop(0)
            speak(stable)
            history_log.appendleft({
                "gesture":    stable,
                "confidence": round(conf * 100, 1),
                "time":       time.strftime("%H:%M:%S"),
                "icon":       ICONS.get(stable, "🤟"),
                "image":      GESTURE_IMAGES.get(stable, "default.png"),
            })

        latest_gesture.update({
            "gesture":    stable,
            "confidence": round(conf * 100, 1),
            "raw":        dict(latest_raw),
            "timestamp":  time.time(),
            "sentence":   list(sentence_words),
            "icon":       ICONS.get(stable, "🤟"),
            "image":      GESTURE_IMAGES.get(stable, "default.png"),
        })

    else:
        # Low confidence — update sensor bars but keep last gesture on screen
        latest_gesture["raw"]        = dict(latest_raw)
        latest_gesture["confidence"] = round(conf * 100, 1)

    return jsonify(latest_gesture), 200

# ── Poll routes for dashboard ──────────────────────────────────
@app.route("/api/latest")
def api_latest():
    return jsonify(latest_gesture)

@app.route("/api/history")
def api_history():
    return jsonify(list(history_log))

@app.route("/api/meta")
def api_meta():
    return jsonify(meta)

@app.route("/api/clear_sentence", methods=["POST"])
def clear_sentence():
    sentence_words.clear()
    latest_gesture["sentence"] = []
    return jsonify({"ok": True})

@app.route("/api/speak", methods=["POST"])
def api_speak():
    text = (request.get_json(silent=True) or {}).get("text", "")
    if text:
        speak(text)
    return jsonify({"ok": True})

@app.route("/health")
def health():
    return jsonify({
        "status":       "ok",
        "model_loaded": model_data is not None,
        "tts":          TTS_OK,
        "gestures":     len(meta.get("gestures", [])),
        "accuracy":     meta.get("accuracy", 0),
    })

# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n🤟 ISL Sign Language — Plan A")
    print("   Open: http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
