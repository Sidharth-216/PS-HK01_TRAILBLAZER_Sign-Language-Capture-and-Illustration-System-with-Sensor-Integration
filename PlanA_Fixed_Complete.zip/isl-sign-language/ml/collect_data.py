#!/usr/bin/env python3
"""
collect_data.py — Collect real glove sensor data
=================================================
This script talks directly to the ESP32's raw HTTP server (port 8080).
The ESP32 must be running in data-collection mode (raw_srv uncommented in main.py).

BEFORE RUNNING:
  1. Flash main.py to ESP32 with raw_srv lines UNCOMMENTED (see below)
  2. Find your ESP32's IP from Thonny serial output after it connects to WiFi
  3. Set ESP32_IP below to that IP
  4. Run: python ml/collect_data.py

HOW TO SWITCH ESP32 TO DATA-COLLECTION MODE:
  In main.py, change this section in run():
    # raw_srv = start_raw_server()     ← uncomment this line
  to:
    raw_srv = start_raw_server()       ← uncommented

  And add the raw server handler inside the while loop.
  (See the DATA COLLECTION MODE section in main.py comments)
"""

import requests, csv, time, os, sys

# ─────────────────────────────────────────────────────────────
# 🔥 EDIT THIS — set to your ESP32's IP address
#    (Thonny serial shows it after WiFi connects: "Connected! IP: 192.168.x.x")
ESP32_IP = "192.168.1.100"
# ─────────────────────────────────────────────────────────────

ESP32_PORT      = 8080               # ESP32 raw server port — NOT 5000
URL             = f"http://{ESP32_IP}:{ESP32_PORT}/raw"
SAVE_PATH       = "ml/data/gesture_data.csv"
FEATURE_COLS    = ["thumb", "index", "middle", "ring", "pinky"]
SAMPLES_PER_GESTURE = 50             # increased from 40 for better accuracy

GESTURES = [
    "A","B","C","D","E","F","G","H","I","K","L",
    "M","N","O","R","S","T","U","V","W","X","Y",
    "Hello","ThankYou","Yes","No","Please","Sorry",
    "Help","Water","Food","Good","Bad","Stop","Come","Go",
]

os.makedirs("ml/data", exist_ok=True)

def get_sensor_reading():
    """Fetch one sensor reading from ESP32 raw server."""
    r = requests.get(URL, timeout=3)
    r.raise_for_status()
    return r.json()

def test_connection():
    """Test ESP32 is reachable before starting."""
    print(f"Testing connection to ESP32 at {URL}...")
    try:
        d = get_sensor_reading()
        print(f"✓ Connected! Sample reading: {d}")
        return True
    except Exception as e:
        print(f"✗ Cannot reach ESP32: {e}")
        print(f"\nCheck:")
        print(f"  1. ESP32 is powered on and showing WiFi connected in Thonny")
        print(f"  2. ESP32_IP is correct (check Thonny serial output)")
        print(f"  3. raw_srv is uncommented in main.py")
        print(f"  4. Laptop and ESP32 are on the same WiFi/hotspot")
        return False

def main():
    print("=" * 45)
    print("  ISL Glove — Data Collection")
    print("=" * 45)
    print(f"ESP32 URL    : {URL}")
    print(f"Samples/gest : {SAMPLES_PER_GESTURE}")
    print(f"Gestures     : {len(GESTURES)}")
    print(f"Total samples: ~{len(GESTURES) * SAMPLES_PER_GESTURE}")
    print(f"Save path    : {SAVE_PATH}")
    print()

    if not test_connection():
        sys.exit(1)

    # Ask which gestures to collect (helpful if you want to do it in batches)
    print("\nOptions:")
    print("  1. Collect ALL gestures (full session ~30 min)")
    print("  2. Collect specific gestures (type numbers separated by space)")
    print()
    for i, g in enumerate(GESTURES):
        print(f"  {i+1:2d}. {g}")
    print()

    choice = input("Enter 1 for all, or gesture numbers (e.g. 1 3 5): ").strip()
    if choice == "1" or choice == "":
        to_collect = GESTURES
    else:
        try:
            indices = [int(x) - 1 for x in choice.split()]
            to_collect = [GESTURES[i] for i in indices if 0 <= i < len(GESTURES)]
        except Exception:
            print("Invalid input — collecting all gestures")
            to_collect = GESTURES

    print(f"\nWill collect: {to_collect}\n")

    write_header = not os.path.exists(SAVE_PATH)

    with open(SAVE_PATH, "a", newline="") as f:
        writer = csv.writer(f)
        if write_header:
            writer.writerow(FEATURE_COLS + ["label"])
            print(f"Created new file: {SAVE_PATH}")

        for gesture in to_collect:
            print(f"\n{'─'*40}")
            input(f"  ➡  Form the '{gesture}' sign and press ENTER to start...")
            print(f"  Capturing {SAMPLES_PER_GESTURE} samples — HOLD the sign steady")

            count    = 0
            errors   = 0

            while count < SAMPLES_PER_GESTURE:
                try:
                    data = get_sensor_reading()
                    row  = [data.get(k, 0) for k in FEATURE_COLS] + [gesture]
                    writer.writerow(row)
                    count  += 1
                    # Live sensor display while collecting
                    vals = " | ".join(f"{k[0].upper()}:{data.get(k,0):4d}" for k in FEATURE_COLS)
                    print(f"  [{count:2d}/{SAMPLES_PER_GESTURE}]  {vals}", end="\r")
                    time.sleep(0.15)   # ~6 samples/sec

                except KeyboardInterrupt:
                    print(f"\n  Skipping '{gesture}'...")
                    break
                except Exception as e:
                    errors += 1
                    print(f"\n  ⚠ Error ({errors}): {e} — retrying...")
                    if errors > 10:
                        print("  Too many errors, check ESP32 connection")
                        break
                    time.sleep(1)

            print(f"\n  ✓ {gesture}: {count} samples saved")

    print("\n" + "=" * 45)
    print("  🎉 Data collection complete!")
    print(f"  File: {SAVE_PATH}")
    print()
    print("  Next step: run  python ml/train_model.py")
    print("  The model will use your real data + synthetic data.")
    print("=" * 45)

if __name__ == "__main__":
    main()
