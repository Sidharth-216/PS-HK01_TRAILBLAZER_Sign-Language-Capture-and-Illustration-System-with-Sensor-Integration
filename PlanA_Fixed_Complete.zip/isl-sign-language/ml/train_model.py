#!/usr/bin/env python3
# ============================================================
#  train_model.py  —  Train gesture classifier
#
#  DATA STRATEGY (3 layers, use all you can get):
#
#  Layer 1 — Online dataset (ASL sensor-based, Kaggle)
#             kaggle.com/datasets/mouadfiali/sensor-based-american-sign-language-recognition
#             → flex sensor + IMU readings, ~1500 samples, 26 ASL letters
#             → We remap ASL letters to ISL equivalents (ISL & ASL alphabets
#               share ~80% of static hand shapes)
#
#  Layer 2 — Synthetic generation
#             We know the ISL finger posture rules (which fingers are up/bent).
#             We generate thousands of idealized samples + Gaussian noise
#             to simulate sensor variance.
#
#  Layer 3 — Your own collected data (from collect_data.py)
#             Even 20-30 samples per gesture on YOUR glove dramatically
#             helps domain adaptation.
#
#  All 3 layers are merged, augmented, and used to train the final model.
#
#  Run:  python ml/train_model.py
#        python ml/train_model.py --no-synthetic    (skip synthetic)
#        python ml/train_model.py --no-download     (skip Kaggle download)
# ============================================================

import os, sys, json, pickle, argparse
import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.metrics import classification_report, accuracy_score

# ── Paths ─────────────────────────────────────────────────────
DATA_DIR   = "ml/data"
MODEL_DIR  = "ml/models"
YOUR_CSV   = f"{DATA_DIR}/gesture_data.csv"
KAGGLE_CSV = f"{DATA_DIR}/kaggle_asl_sensor.csv"
SYNTH_CSV  = f"{DATA_DIR}/synthetic_isl.csv"
MERGED_CSV = f"{DATA_DIR}/merged_training.csv"
MODEL_PATH = f"{MODEL_DIR}/gesture_model.pkl"
META_PATH  = f"{MODEL_DIR}/gesture_meta.json"

os.makedirs(DATA_DIR,  exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

FEATURE_COLS = ["thumb", "index", "middle", "ring", "pinky"]

# ── ISL Static Gesture Finger Posture Map ────────────────────
# Each value = [thumb, index, middle, ring, pinky]
# 0.0 = fully straight, 1.0 = fully bent
# ADC: flat ~1750, bent ~3100

ISL_POSTURES = {
    # ── ISL Alphabets ────────────────────────────────────────
    "A":         [1.0, 1.0, 1.0, 1.0, 0.2],
    "B":         [0.1, 0.0, 0.0, 0.0, 0.0],
    "C":         [0.4, 0.4, 0.4, 0.4, 0.4],
    "D":         [0.2, 0.0, 1.0, 1.0, 1.0],
    "E":         [0.9, 0.8, 0.8, 0.8, 0.8],
    "F":         [0.5, 0.5, 0.0, 0.0, 0.0],
    "G":         [0.2, 0.0, 1.0, 1.0, 0.8],
    "H":         [0.8, 0.0, 0.0, 1.0, 1.0],
    "I":         [1.0, 1.0, 1.0, 1.0, 0.0],
    "K":         [0.2, 0.0, 0.3, 1.0, 1.0],
    "L":         [0.0, 0.0, 1.0, 1.0, 1.0],
    "M":         [0.8, 0.8, 0.8, 0.8, 0.8],
    "N":         [0.9, 0.9, 0.9, 0.9, 0.8],
    "O":         [0.5, 0.5, 0.5, 0.5, 0.5],
    "R":         [0.8, 0.0, 0.1, 1.0, 1.0],
    "S":         [0.9, 0.9, 0.9, 0.9, 0.9],
    "T":         [0.8, 0.9, 0.9, 0.9, 0.9],
    "U":         [0.8, 0.0, 0.0, 1.0, 1.0],
    "V":         [0.8, 0.0, 0.0, 1.0, 1.0],
    "W":         [0.7, 0.0, 0.0, 0.0, 1.0],
    "X":         [0.8, 0.4, 1.0, 1.0, 1.0],
    "Y":         [0.0, 1.0, 1.0, 1.0, 0.0],
    # ── Common ISL Words ─────────────────────────────────────
    "Hello":     [0.1, 0.0, 0.0, 0.0, 0.0],
    "ThankYou":  [0.2, 0.2, 0.2, 0.2, 0.2],
    "Yes":       [1.0, 1.0, 1.0, 1.0, 1.0],
    "No":        [0.8, 0.0, 1.0, 1.0, 1.0],
    "Please":    [0.3, 0.3, 0.3, 0.3, 0.3],
    "Sorry":     [0.95,0.95,0.95,0.95,0.95],
    "Help":      [0.0, 1.0, 1.0, 1.0, 1.0],
    "Water":     [0.7, 0.0, 0.0, 0.0, 1.0],
    "Food":      [0.5, 0.5, 0.5, 0.5, 0.5],
    "Good":      [0.2, 0.2, 0.2, 0.2, 0.2],
    "Bad":       [0.9, 0.8, 0.8, 0.8, 0.7],
    "Stop":      [0.2, 0.0, 0.0, 0.0, 0.0],
    "Come":      [0.3, 0.1, 0.1, 0.1, 0.1],
    "Go":        [0.3, 0.0, 0.0, 0.0, 0.0],
}

ADC_FLAT = 1750
ADC_BENT = 3100


def posture_to_adc(postures, n_samples=200, noise_std=0.06):
    rows = []
    for _ in range(n_samples):
        row = []
        for p in postures:
            p_n = float(np.clip(p + np.random.normal(0, noise_std), 0.0, 1.0))
            adc = ADC_FLAT + p_n * (ADC_BENT - ADC_FLAT)
            adc += np.random.normal(0, 60)
            row.append(int(np.clip(adc, 0, 4095)))
        rows.append(row)
    return rows


def generate_synthetic(n_per_gesture=250):
    print(f"\n[SYNTHETIC] Generating {n_per_gesture} x {len(ISL_POSTURES)} gestures...")
    records = []
    for label, postures in ISL_POSTURES.items():
        for row in posture_to_adc(postures, n_samples=n_per_gesture):
            records.append(row + [label])
    df = pd.DataFrame(records, columns=FEATURE_COLS + ["label"])
    df.to_csv(SYNTH_CSV, index=False)
    print(f"[SYNTHETIC] {len(df)} rows -> {SYNTH_CSV}")
    return df


def try_download_kaggle():
    print("\n[KAGGLE] Attempting download...")
    try:
        import subprocess
        r = subprocess.run(
            ["kaggle", "datasets", "download",
             "-d", "mouadfiali/sensor-based-american-sign-language-recognition",
             "-p", DATA_DIR, "--unzip"],
            capture_output=True, text=True, timeout=120
        )
        if r.returncode == 0:
            print("[KAGGLE] Download successful")
            return True
        print(f"[KAGGLE] Failed: {r.stderr.strip()}")
        return False
    except FileNotFoundError:
        print("[KAGGLE] kaggle CLI not installed (pip install kaggle)")
        return False
    except Exception as e:
        print(f"[KAGGLE] Error: {e}")
        return False


ASL_TO_ISL_KEEP = {
    "A","B","C","D","E","F","G","H","I","K","L",
    "M","N","O","R","S","T","U","V","W","X","Y"
}

def load_and_remap_kaggle():
    for f in os.listdir(DATA_DIR):
        if not f.endswith(".csv"):
            continue
        if f in [os.path.basename(p) for p in [YOUR_CSV, SYNTH_CSV, MERGED_CSV]]:
            continue
        try:
            df = pd.read_csv(os.path.join(DATA_DIR, f))
            cols_lower = {c.lower(): c for c in df.columns}
            mapping = {}
            for canon, aliases in {
                "thumb":  ["thumb","flex1","flex_1","f1","sensor1","ch1"],
                "index":  ["index","flex2","flex_2","f2","sensor2","ch2"],
                "middle": ["middle","flex3","flex_3","f3","sensor3","ch3"],
                "ring":   ["ring","flex4","flex_4","f4","sensor4","ch4"],
                "pinky":  ["pinky","little","flex5","flex_5","f5","sensor5","ch5"],
            }.items():
                for alias in aliases:
                    if alias in cols_lower:
                        mapping[canon] = cols_lower[alias]
                        break
            label_col = next(
                (cols_lower[lc] for lc in ["label","gesture","class","sign","letter"] if lc in cols_lower),
                None
            )
            if len(mapping) >= 4 and label_col:
                out = df[[v for v in mapping.values()]].copy()
                out.columns = list(mapping.keys())
                out["label"] = df[label_col].astype(str).str.strip().str.upper()
                out = out[out["label"].isin(ASL_TO_ISL_KEEP)]
                for col in list(mapping.keys()):
                    vmax = out[col].max()
                    if vmax <= 1.0:   out[col] = (out[col] * 4095).astype(int)
                    elif vmax <= 1024: out[col] = (out[col] * 4).astype(int)
                print(f"[KAGGLE] Loaded {len(out)} rows from {f}")
                return out
        except Exception as e:
            print(f"[KAGGLE] Skipping {f}: {e}")
    return None


def load_your_data():
    if not os.path.exists(YOUR_CSV):
        print("[YOUR DATA] Not found — run collect_data.py first")
        return None
    df = pd.read_csv(YOUR_CSV)
    if not all(c in df.columns for c in FEATURE_COLS + ["label"]):
        print("[YOUR DATA] Unexpected columns — skipping")
        return None
    print(f"[YOUR DATA] {len(df)} rows, {df['label'].nunique()} gestures")
    return df[FEATURE_COLS + ["label"]]


def augment(df, n=4, noise_std=50):
    copies = [df.copy()]
    for _ in range(n):
        aug = df.copy()
        for col in FEATURE_COLS:
            if col in aug.columns:
                aug[col] = (aug[col] + np.random.normal(0, noise_std, len(aug))).clip(0, 4095).astype(int)
        copies.append(aug)
    return pd.concat(copies, ignore_index=True)


def merge_all(use_synthetic=True, use_kaggle=True):
    parts = []

    if use_synthetic:
        parts.append(generate_synthetic(n_per_gesture=250))

    if use_kaggle:
        kaggle_df = load_and_remap_kaggle()
        if kaggle_df is not None:
            parts.append(kaggle_df)
        else:
            print("[KAGGLE] No data found. Setup instructions:")
            print("  1.  pip install kaggle")
            print("  2.  kaggle.com/account  ->  Create New Token  ->  save to ~/.kaggle/kaggle.json")
            print("  3.  Re-run this script (it will auto-download)")
            print("  OR: Manually download CSV from:")
            print("      kaggle.com/datasets/mouadfiali/sensor-based-american-sign-language-recognition")
            print("      and place in ml/data/\n")

    your_df = load_your_data()
    if your_df is not None:
        parts.append(augment(your_df, n=8, noise_std=40))
        print(f"[YOUR DATA] After 8x augmentation: {len(parts[-1])} rows")

    if not parts:
        print("\n✗ NO DATA. Run ml/collect_data.py first.")
        sys.exit(1)

    merged = pd.concat(parts, ignore_index=True).dropna(subset=FEATURE_COLS)
    merged.to_csv(MERGED_CSV, index=False)

    print(f"\n[MERGED] {len(merged)} total rows | {merged['label'].nunique()} gestures")
    print("Class distribution:")
    for lbl, cnt in merged["label"].value_counts().items():
        print(f"  {lbl:<14} {cnt:>6}  {'█' * (cnt // 30)}")
    return merged


def train(df):
    X    = df[FEATURE_COLS].values
    y    = df["label"].values
    le   = LabelEncoder()
    y_e  = le.fit_transform(y)
    sc   = StandardScaler()
    X_sc = sc.fit_transform(X)

    print("\n── Cross-validation (5-fold) ─────────────────────")
    candidates = {
        "RandomForest":     RandomForestClassifier(n_estimators=400, max_depth=14,
                                                    min_samples_leaf=2, random_state=42, n_jobs=-1),
        "GradientBoosting": GradientBoostingClassifier(n_estimators=250, learning_rate=0.08,
                                                        max_depth=5, random_state=42),
        "SVM_RBF":          SVC(kernel="rbf", C=15, gamma="scale", probability=True, random_state=42),
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    best_name, best_score, best_model = None, 0, None
    for name, clf in candidates.items():
        scores = cross_val_score(clf, X_sc, y_e, cv=cv, scoring="accuracy", n_jobs=-1)
        m, s = scores.mean(), scores.std()
        print(f"  {name:<22} {m*100:5.1f}% ±{s*100:.1f}%  {'█'*int(m*30)}")
        if m > best_score:
            best_score, best_name, best_model = m, name, clf

    print(f"\n  Best: {best_name} ({best_score*100:.1f}%)")
    X_tr, X_te, y_tr, y_te = train_test_split(X_sc, y_e, test_size=0.15, random_state=42, stratify=y_e)
    best_model.fit(X_tr, y_tr)
    y_pred = best_model.predict(X_te)
    acc = accuracy_score(y_te, y_pred)

    print(f"\nTest Accuracy: {acc*100:.2f}%")
    print(classification_report(y_te, y_pred, target_names=le.classes_))

    with open(MODEL_PATH, "wb") as f:
        pickle.dump({"model": best_model, "scaler": sc, "encoder": le}, f)
    with open(META_PATH, "w") as f:
        json.dump({"model_type": best_name, "accuracy": round(acc*100,2),
                   "gestures": list(le.classes_), "n_features": len(FEATURE_COLS),
                   "feature_cols": FEATURE_COLS, "n_samples": len(df)}, f, indent=2)

    print(f"\n✓ Saved model  -> {MODEL_PATH}")
    print(f"✓ Saved meta   -> {META_PATH}")
    if acc < 0.85:
        print("\n⚠ Accuracy < 85%. Collect more real samples (aim 50+/gesture)")
    else:
        print("\n🎉 Ready to deploy!")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--no-synthetic",  action="store_true")
    p.add_argument("--no-download",   action="store_true")
    p.add_argument("--download-only", action="store_true")
    args = p.parse_args()

    print("=" * 55)
    print("  ISL Sign Language — Model Training")
    print("=" * 55)

    if args.download_only:
        try_download_kaggle(); sys.exit(0)

    if not args.no_download:
        try_download_kaggle()

    df = merge_all(use_synthetic=not args.no_synthetic,
                   use_kaggle=not args.no_download)
    train(df)
