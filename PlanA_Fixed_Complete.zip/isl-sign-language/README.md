# 🤟 ISL Sign Language Capture & Translation System
### PS-HK01 — Hacknovation 2.0

---

## 📁 Folder Structure

```
isl-sign-language/
│
├── esp32_firmware/          ← Flash these to the ESP32 glove
│   ├── boot.py              ← Runs on every power-on (minimal)
│   ├── main.py              ← Main glove firmware loop
│   └── config.py            ← ⚠ EDIT: WiFi credentials & server IP
│
├── ml/
│   ├── collect_data.py      ← Step 1: Gather training samples
│   ├── train_model.py       ← Step 2: Train & save the classifier
│   ├── data/
│   │   └── gesture_data.csv ← Auto-created by collect_data.py
│   └── models/
│       ├── gesture_model.pkl ← Auto-created by train_model.py
│       └── gesture_meta.json ← Model metadata
│
├── backend/
│   ├── app.py               ← Flask server (run this on laptop)
│   ├── templates/
│   │   └── index.html       ← Live dashboard UI
│   └── static/
│       ├── css/
│       ├── js/
│       └── images/          ← Put gesture illustration PNGs here
│
├── requirements.txt
└── README.md
```

---

## ⚡ Wiring Quick Reference

```
ESP32 Pin  │ Component        │ Notes
───────────┼──────────────────┼──────────────────────────────
GPIO 34    │ Flex Sensor 1    │ Thumb   + 10kΩ to GND
GPIO 35    │ Flex Sensor 2    │ Index   + 10kΩ to GND
GPIO 32    │ Flex Sensor 3    │ Middle  + 10kΩ to GND
GPIO 33    │ Flex Sensor 4    │ Ring    + 10kΩ to GND
GPIO 25    │ Flex Sensor 5    │ Pinky   + 10kΩ to GND
GPIO 27    │ PIR OUT          │ Motion trigger
3.3V       │ All sensors VCC  │
GND        │ All sensors GND  │
```

**Voltage divider per flex sensor:**
```
3.3V ──── [Flex Sensor] ──┬── GPIO (ADC)
                          │
                       [10kΩ]
                          │
                         GND
```

---

## 🚀 Setup Steps (Hackathon Order)

### Step 1 — Flash ESP32 (Thonny IDE)
1. Connect ESP32 via USB
2. Open Thonny → Tools → Options → Interpreter → MicroPython (ESP32)
3. Edit `esp32_firmware/config.py` with your WiFi SSID/password and laptop IP
4. Upload all 3 files: `boot.py`, `config.py`, `main.py`
5. Check console — should print IP address when connected

### Step 2 — Install Python deps (Laptop)
```bash
pip install -r requirements.txt
```

### Step 3 — Collect training data
```bash
# Edit ESP32_IP in ml/collect_data.py first!
python ml/collect_data.py
```
- Follow prompts for each gesture
- Aim for 50 samples per gesture
- Takes ~15 minutes for 15 gestures

### Step 4 — Train the model
```bash
python ml/train_model.py
```
- Compares Random Forest, Gradient Boosting, SVM
- Saves best model automatically
- Goal: >85% accuracy

### Step 5 — Start Flask server
```bash
cd backend
python app.py
```

### Step 6 — Open dashboard
```
http://localhost:5000
```

---

## 🎯 Target Gestures (ISL)

| Gesture  | Description              |
|----------|--------------------------|
| A–E      | ISL alphabet letters     |
| Hello    | Open palm wave           |
| ThankYou | Flat hand from chin      |
| Yes      | Fist nod                 |
| No       | Index finger wag         |
| Please   | Hand on chest circular   |
| Sorry    | Fist circle on chest     |
| Help     | Thumb up on open palm    |
| Water    | W at mouth               |
| Good     | Flat hand chin forward   |

---

## 📊 Accuracy Tips

- Collect 50+ samples per gesture (not 30)
- Have 2-3 people contribute samples for each gesture
- Recalibrate flat/bent values in config.py for your glove
- If accuracy < 85%, remove confusing gestures and retrain
- Use the waveform display to spot noisy sensors

---

## 🏆 Judging Demo Script

1. Show the live dashboard with sensor bars moving
2. Sign "Hello" → system speaks and displays it
3. Build a sentence: Hello + Please + Help
4. Click "Speak" to read full sentence aloud
5. Show training pipeline briefly (show the CSV + train command)
6. Show model accuracy stats in dashboard

---

*Built for Hacknovation 2.0 · GIET University · Feb 2026*
